export const todayDeal = [
    {
        img : "https://m.media-amazon.com/images/I/41Diz41FkhL.AC_SY200.jpg",
        discount : 32,
        DealOfDay : "Deal of the Day",
        desc : " Grand Gaming Days offers on Bestselling Gaming Laptops & Desktops - Exchange & No Cost EMI Available"
    },
    {
        img : "https://m.media-amazon.com/images/I/41DjFnGQ1FL.AC_SY200.jpg",
        discount : 31,
        DealOfDay : "Deal of the Day",
        desc : "High Performance Handpicked Desktop Computers from HP, Lenovo and more"
    },
    {
        img : "https://m.media-amazon.com/images/I/31aNgbvYJKL.AC_SY200.jpg",
        discount : 66,
        DealOfDay : "Deal of the Day",
        desc : "Best Prices on boAt Headphones, Soundbars and Speakers"
    },
    {
        img : "https://m.media-amazon.com/images/I/31G1NouVxaL.AC_SY200.jpg",
        discount : 80,
        DealOfDay : "Deal of the Day",
        desc : "Jaw dropping deals on headsets"
    },

    {
        img : "https://m.media-amazon.com/images/I/31EXkIBVKUL.AC_SY200.jpg",
        discount : 50,
        DealOfDay : "Deal of the Day",
        desc : "adidas & campus Footwear"
    },
    {
        img : "https://m.media-amazon.com/images/I/416x-scGWgL.AC_SY200.jpg",
        discount : 64,
        DealOfDay : "Deal of the Day",
        desc : "Grand Gaming Days Offers on Accessories and Storage Devices"
    },

    {
        img : "https://m.media-amazon.com/images/I/31VfkewLnlL.AC_SY200.jpg",
        discount : 54,
        DealOfDay : "Deal of the Day",
        desc : "cooking essential"
    },
    {
        img : "https://m.media-amazon.com/images/I/91kKqnkv9jL.AC_SY200.jpg",
        discount : 52,
        DealOfDay : "Deal of the Day",
        desc : "TOP Deals on PUMA & Skechers footwear"
    },

    {
        img : "https://m.media-amazon.com/images/I/41fsUIG2fwL.AC_SY200.jpg",
        discount : 12,
        DealOfDay : "Deal of the Day",
        desc : "Handpicked Intel Powered Laptops; High Performance"
    },
    {
        img : "https://m.media-amazon.com/images/I/317lhW5iHVL.AC_SY200.jpg",
        discount : 65,
        DealOfDay : "Deal of the Day",
        desc : "Powerbank from Mi, Ambrane, URBN and more"
    },

    {
        img : "https://m.media-amazon.com/images/I/41yxd6A+ZAL.AC_SY200.jpg",
        discount : 65,
        DealOfDay : "Deal of the Day",
        desc : "Top deals on Truke, Govo and more"
    },
    {
        img : "https://m.media-amazon.com/images/I/41wcMkODJLL.AC_SY200.jpg",
        discount : 75,
        DealOfDay : "Deal of the Day",
        desc : "Amazing deals on pTron, Jabra, Portronics"
    },
    {
        img : "https://m.media-amazon.com/images/I/61QQtY6qtHL.AC_SY200.jpg",
        discount : 82,
        DealOfDay : "Deal of the Day",
        desc : "Levi's, Allen Solly, ANNI DESIGNER, Janasya & more"
    },
    {
        img : "https://m.media-amazon.com/images/I/31aTPRvXiSL.AC_SY200.jpg",
        discount : 77,
        DealOfDay : "Deal of the Day",
        desc : "Exciting  deals on Mivi, Wecool, Wings"
    },
    {
        img : "https://m.media-amazon.com/images/I/21wNUazPKRL.AC_SY200.jpg",
        discount : 20,
        DealOfDay : "Deal of the Day",
        desc : "Never before deals on HP printers"
    },
    {
        img : "https://m.media-amazon.com/images/I/41bFnhrsyOL.AC_SY200.jpg",
        discount : 19,
        DealOfDay : "Deal of the Day",
        desc : "Vivo Y75 - 18W fast charge, FHD plus display"
    },
    {
        img : "https://m.media-amazon.com/images/I/41wyFlObIrL.AC_SY200.jpg",
        discount : "25",
        DealOfDay : "Deal of the Day",
        desc : "Nokia 5710 - newly launched 4G feature phone"
    },
    {
        img : "https://m.media-amazon.com/images/I/31Zq-alRH9L.AC_SY200.jpg",
        discount : 32,
        DealOfDay : "Deal of the Day",
        desc : "Vacuum Cleaners from Top Brands"
    },



]